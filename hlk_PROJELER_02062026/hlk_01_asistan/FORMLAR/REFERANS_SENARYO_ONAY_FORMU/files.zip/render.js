/**
 * Kullanım:
 *   npm install puppeteer
 *   node render.js sample-data.json cikti.png
 *
 * Telegram botunda kullanım:
 *   1) O anki senaryo verisini bir JS objesi olarak hazırla (sample-data.json'daki yapıyla aynı)
 *   2) renderForm(data) fonksiyonunu çağır, dönen PNG buffer'ını Telegram'a gönder
 */
const fs = require('fs');
const path = require('path');
const puppeteer = require('puppeteer');

async function renderForm(data, outputPath) {
  const templatePath = path.join(__dirname, 'template.html');
  let html = fs.readFileSync(templatePath, 'utf-8');
  html = html.replace('{{DATA_JSON}}', JSON.stringify(data));

  const browser = await puppeteer.launch({
    headless: 'new',
    args: ['--no-sandbox', '--disable-setuid-sandbox']
  });
  const page = await browser.newPage();
  await page.setViewport({ width: 1100, height: 800, deviceScaleFactor: 2 }); // deviceScaleFactor=2 -> keskin/retina PNG
  await page.setContent(html, { waitUntil: 'networkidle0' });

  const sheet = await page.$('#sheet');
  await sheet.screenshot({ path: outputPath });

  await browser.close();
  console.log('Oluşturuldu:', outputPath);
}

// CLI kullanım
if (require.main === module) {
  const dataPath = process.argv[2] || 'sample-data.json';
  const outPath = process.argv[3] || 'cikti.png';
  const data = JSON.parse(fs.readFileSync(dataPath, 'utf-8'));
  renderForm(data, outPath);
}

module.exports = { renderForm };
